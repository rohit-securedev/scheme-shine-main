import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import NewIndex from "./pages/NewIndex";
import Dashboard from "./pages/Dashboard";
import ApplicantPortal from "./pages/ApplicantPortal";
import Allocations from "./pages/Allocations";
import SimpleAnalytics from "./pages/SimpleAnalytics";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<NewIndex />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/apply" element={<ApplicantPortal />} />
          <Route path="/applicants" element={<ApplicantPortal />} />
          <Route path="/allocations" element={<Allocations />} />
          <Route path="/analytics" element={<SimpleAnalytics />} />
          <Route path="/internships" element={<Dashboard />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
