import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { dummyApplicants, dummyInternships, generateDummyAllocations } from "@/data/dummyData";
import { useMemo } from "react";
import { TrendingUp, Users, Target, Award, MapPin, GraduationCap, Briefcase, Star } from "lucide-react";

const SimpleAnalytics = () => {
  const allocations = useMemo(() => generateDummyAllocations(), []);

  const analyticsData = useMemo(() => {
    // Skills distribution
    const skillsCount: Record<string, number> = {};
    dummyApplicants.forEach(applicant => {
      applicant.skills.forEach(skill => {
        skillsCount[skill] = (skillsCount[skill] || 0) + 1;
      });
    });
    const topSkills = Object.entries(skillsCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 8);

    // Category distribution
    const categoryData = Object.entries(
      dummyApplicants.reduce((acc, applicant) => {
        acc[applicant.category] = (acc[applicant.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    ).map(([name, value]) => ({ name, value }));

    // Gender distribution
    const genderData = Object.entries(
      dummyApplicants.reduce((acc, applicant) => {
        acc[applicant.gender] = (acc[applicant.gender] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    ).map(([name, value]) => ({ name, value }));

    // Location distribution
    const locationData = Object.entries(
      dummyApplicants.reduce((acc, applicant) => {
        acc[applicant.location] = (acc[applicant.location] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    ).map(([name, value]) => ({ name, value }));

    // Match score distribution
    const matchScoreRanges = [
      { range: '90-100%', count: allocations.filter(a => a.matchScore >= 90).length },
      { range: '80-89%', count: allocations.filter(a => a.matchScore >= 80 && a.matchScore < 90).length },
      { range: '70-79%', count: allocations.filter(a => a.matchScore >= 70 && a.matchScore < 80).length },
      { range: '60-69%', count: allocations.filter(a => a.matchScore >= 60 && a.matchScore < 70).length },
      { range: '<60%', count: allocations.filter(a => a.matchScore < 60).length },
    ];

    // Domain distribution
    const domainData = Object.entries(
      dummyInternships.reduce((acc, internship) => {
        acc[internship.domain] = (acc[internship.domain] || 0) + internship.capacity;
        return acc;
      }, {} as Record<string, number>)
    ).map(([name, value]) => ({ name, value }));

    return {
      topSkills,
      categoryData,
      genderData,
      locationData,
      matchScoreRanges,
      domainData
    };
  }, [allocations]);

  const keyMetrics = useMemo(() => {
    const totalApplicants = dummyApplicants.length;
    const totalPositions = dummyInternships.reduce((sum, int) => sum + int.capacity, 0);
    const allocated = allocations.filter(a => a.status === 'Allocated').length;
    const avgMatchScore = Math.round(
      allocations.reduce((sum, a) => sum + a.matchScore, 0) / allocations.length
    );
    const avgPreferenceRank = Math.round(
      allocations.reduce((sum, a) => sum + a.preferenceRank, 0) / allocations.length * 10
    ) / 10;

    return {
      totalApplicants,
      totalPositions,
      allocated,
      allocationRate: Math.round((allocated / totalApplicants) * 100),
      avgMatchScore,
      avgPreferenceRank,
      satisfactionRate: 87, // Mock satisfaction rate
      diversityIndex: 0.73, // Mock diversity index
    };
  }, [allocations]);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Analytics & Insights</h1>
          <p className="text-muted-foreground">
            Comprehensive analysis of the PM Internship allocation process
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Allocation Efficiency</CardTitle>
              <Target className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{keyMetrics.allocationRate}%</div>
              <Progress value={keyMetrics.allocationRate} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-2">
                {keyMetrics.allocated} out of {keyMetrics.totalApplicants} allocated
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Match Quality</CardTitle>
              <Award className="h-4 w-4 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary">{keyMetrics.avgMatchScore}%</div>
              <Progress value={keyMetrics.avgMatchScore} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-2">Average AI match score</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Preference Satisfaction</CardTitle>
              <Star className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">{keyMetrics.avgPreferenceRank}</div>
              <p className="text-xs text-muted-foreground mt-2">Average preference rank achieved</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Diversity Index</CardTitle>
              <Users className="h-4 w-4 text-primary-glow" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-glow">{keyMetrics.diversityIndex}</div>
              <Progress value={keyMetrics.diversityIndex * 100} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-2">Inclusion across categories</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Skills Distribution */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-primary" />
                Top Skills in Demand
              </CardTitle>
              <CardDescription>Most frequently mentioned skills by applicants</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.topSkills.map(([skill, count]) => (
                  <div key={skill} className="flex items-center justify-between">
                    <Badge variant="secondary" className="font-medium">{skill}</Badge>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-muted rounded h-2">
                        <div 
                          className="bg-primary h-2 rounded" 
                          style={{ width: `${(count / dummyApplicants.length) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-8">{count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Match Score Distribution */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-secondary" />
                Match Score Distribution
              </CardTitle>
              <CardDescription>Distribution of AI matching scores</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.matchScoreRanges.map((range) => (
                  <div key={range.range} className="flex items-center justify-between">
                    <span className="font-medium">{range.range}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-muted rounded h-2">
                        <div 
                          className="bg-secondary h-2 rounded" 
                          style={{ width: `${(range.count / allocations.length) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-8">{range.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Category Distribution */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Category Distribution
              </CardTitle>
              <CardDescription>Reservation category breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.categoryData.map(({ name, value }) => (
                  <div key={name} className="flex items-center justify-between">
                    <span className="font-medium">{name}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-muted rounded h-2">
                        <div 
                          className="bg-primary h-2 rounded" 
                          style={{ width: `${(value / dummyApplicants.length) * 100}%` }}
                        />
                      </div>
                      <Badge variant="secondary">{value}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Gender Distribution */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-secondary" />
                Gender Distribution
              </CardTitle>
              <CardDescription>Gender diversity in applicants</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.genderData.map(({ name, value }) => (
                  <div key={name} className="flex items-center justify-between">
                    <span className="font-medium">{name}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-muted rounded h-2">
                        <div 
                          className="bg-secondary h-2 rounded" 
                          style={{ width: `${(value / dummyApplicants.length) * 100}%` }}
                        />
                      </div>
                      <Badge variant="secondary">{value}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Domain Distribution */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-accent" />
                Domain Distribution
              </CardTitle>
              <CardDescription>Available positions by domain</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.domainData.map(({ name, value }) => (
                  <div key={name} className="flex items-center justify-between">
                    <span className="font-medium">{name}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-muted rounded h-2">
                        <div 
                          className="bg-accent h-2 rounded" 
                          style={{ width: `${(value / dummyInternships.reduce((sum, int) => sum + int.capacity, 0)) * 100}%` }}
                        />
                      </div>
                      <Badge variant="secondary">{value}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Location Analysis */}
        <Card className="bg-gradient-card border-0 shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Geographic Distribution
            </CardTitle>
            <CardDescription>Applicant distribution across locations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {analyticsData.locationData.map(({ name, value }) => (
                <div key={name} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-16 bg-muted rounded h-2">
                      <div 
                        className="bg-primary h-2 rounded" 
                        style={{ width: `${(value / dummyApplicants.length) * 100}%` }}
                      />
                    </div>
                    <Badge variant="secondary">{value}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SimpleAnalytics;