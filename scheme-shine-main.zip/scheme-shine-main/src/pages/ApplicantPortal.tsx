import { Button } from "@/components/ui/enhanced-button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { dummyInternships } from "@/data/dummyData";
import { useState } from "react";
import { User, Mail, Phone, MapPin, GraduationCap, Award, Briefcase, Star, Clock, Building2, IndianRupee } from "lucide-react";

const ApplicantPortal = () => {
  const [selectedInternships, setSelectedInternships] = useState<string[]>([]);

  const handleInternshipSelect = (internshipId: string) => {
    if (selectedInternships.includes(internshipId)) {
      setSelectedInternships(prev => prev.filter(id => id !== internshipId));
    } else if (selectedInternships.length < 3) {
      setSelectedInternships(prev => [...prev, internshipId]);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold bg-gradient-hero bg-clip-text text-transparent mb-4">
            Apply for PM Internship Scheme
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Join India's flagship internship program and kickstart your career with leading organizations
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Application Form */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  Personal Information
                </CardTitle>
                <CardDescription>Please fill in your basic details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input id="fullName" placeholder="Enter your full name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" type="email" placeholder="your.email@example.com" />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" placeholder="+91-XXXXXXXXXX" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="age">Age</Label>
                    <Input id="age" type="number" placeholder="22" />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General</SelectItem>
                        <SelectItem value="obc">OBC</SelectItem>
                        <SelectItem value="sc">SC</SelectItem>
                        <SelectItem value="st">ST</SelectItem>
                        <SelectItem value="ews">EWS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Current Location</Label>
                  <Input id="location" placeholder="City, State" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <GraduationCap className="h-5 w-5 text-secondary" />
                  Educational Background
                </CardTitle>
                <CardDescription>Tell us about your academic qualifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="education">Highest Qualification</Label>
                    <Input id="education" placeholder="B.Tech Computer Science" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cgpa">CGPA/Percentage</Label>
                    <Input id="cgpa" type="number" step="0.1" placeholder="8.5" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="skills">Technical Skills</Label>
                  <Textarea 
                    id="skills" 
                    placeholder="React, Node.js, Python, Machine Learning, etc. (comma-separated)"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="experience">Relevant Experience</Label>
                  <Textarea 
                    id="experience" 
                    placeholder="Describe any internships, projects, or work experience..."
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-accent" />
                  Internship Preferences
                </CardTitle>
                <CardDescription>
                  Select up to 3 internships in order of preference
                  {selectedInternships.length > 0 && (
                    <span className="ml-2 text-primary">
                      ({selectedInternships.length}/3 selected)
                    </span>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {dummyInternships.slice(0, 6).map((internship, index) => (
                    <div
                      key={internship.id}
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                        selectedInternships.includes(internship.id)
                          ? 'border-primary bg-primary/5 shadow-glow'
                          : 'border-border hover:border-primary/50 hover:shadow-card'
                      }`}
                      onClick={() => handleInternshipSelect(internship.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-foreground">{internship.title}</h3>
                            {selectedInternships.includes(internship.id) && (
                              <Badge variant="default" className="text-xs">
                                Preference #{selectedInternships.indexOf(internship.id) + 1}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                            <div className="flex items-center gap-1">
                              <Building2 className="h-3 w-3" />
                              {internship.company}
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {internship.location}
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {internship.duration}
                            </div>
                            <div className="flex items-center gap-1">
                              <IndianRupee className="h-3 w-3" />
                              ₹{internship.stipend.toLocaleString()}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {internship.requiredSkills.slice(0, 4).map(skill => (
                              <Badge key={skill} variant="secondary" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                            {internship.requiredSkills.length > 4 && (
                              <Badge variant="outline" className="text-xs">
                                +{internship.requiredSkills.length - 4} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-end gap-4">
              <Button variant="outline" size="lg">
                Save as Draft
              </Button>
              <Button variant="hero" size="lg">
                Submit Application
              </Button>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  Application Tips
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                    <p>Complete all sections for better matching accuracy</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-secondary rounded-full mt-2 flex-shrink-0" />
                    <p>List specific technical skills to improve match scores</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-accent rounded-full mt-2 flex-shrink-0" />
                    <p>Select internship preferences carefully - they affect allocation</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-primary-glow rounded-full mt-2 flex-shrink-0" />
                    <p>Higher CGPA increases chances of preferred allocations</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5 text-secondary" />
                  Program Statistics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">{dummyInternships.length}</div>
                    <div className="text-sm text-muted-foreground">Programs</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-secondary">
                      {dummyInternships.reduce((sum, int) => sum + int.capacity, 0)}
                    </div>
                    <div className="text-sm text-muted-foreground">Positions</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">₹28K</div>
                    <div className="text-sm text-muted-foreground">Avg Stipend</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-primary-glow">85%</div>
                    <div className="text-sm text-muted-foreground">Success Rate</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-success border-0 shadow-card">
              <CardContent className="pt-6">
                <div className="text-center text-white">
                  <Award className="h-8 w-8 mx-auto mb-3" />
                  <h3 className="text-lg font-semibold mb-2">Apply Now!</h3>
                  <p className="text-sm opacity-90">
                    Join thousands of successful interns who launched their careers through this program.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicantPortal;