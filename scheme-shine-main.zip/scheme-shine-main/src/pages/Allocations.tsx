import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/enhanced-button";
import { Input } from "@/components/ui/input";
import { dummyApplicants, dummyInternships, generateDummyAllocations } from "@/data/dummyData";
import { useMemo, useState } from "react";
import { Search, FileText, Download, Eye, CheckCircle, Clock, XCircle, TrendingUp, User, Briefcase } from "lucide-react";

const Allocations = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const allocations = useMemo(() => generateDummyAllocations(), []);

  const enrichedAllocations = useMemo(() => {
    return allocations.map(allocation => {
      const applicant = dummyApplicants.find(a => a.id === allocation.applicantId);
      const internship = dummyInternships.find(i => i.id === allocation.internshipId);
      return { ...allocation, applicant, internship };
    });
  }, [allocations]);

  const filteredAllocations = useMemo(() => {
    return enrichedAllocations.filter(allocation => 
      allocation.applicant?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      allocation.internship?.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      allocation.internship?.company.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [enrichedAllocations, searchTerm]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Allocated':
        return <CheckCircle className="h-4 w-4 text-secondary" />;
      case 'Waitlisted':
        return <Clock className="h-4 w-4 text-accent" />;
      case 'Not Allocated':
        return <XCircle className="h-4 w-4 text-destructive" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Allocated':
        return 'bg-secondary text-secondary-foreground';
      case 'Waitlisted':
        return 'bg-accent text-accent-foreground';
      case 'Not Allocated':
        return 'bg-destructive text-destructive-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const statusCounts = useMemo(() => {
    return allocations.reduce((acc, allocation) => {
      acc[allocation.status] = (acc[allocation.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
  }, [allocations]);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Allocation Results</h1>
          <p className="text-muted-foreground">AI-powered smart matching results for PM Internship Scheme</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Allocations</CardTitle>
              <TrendingUp className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{allocations.length}</div>
              <p className="text-xs text-muted-foreground">Processed applications</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Successfully Allocated</CardTitle>
              <CheckCircle className="h-4 w-4 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary">{statusCounts['Allocated'] || 0}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round(((statusCounts['Allocated'] || 0) / allocations.length) * 100)}% success rate
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Waitlisted</CardTitle>
              <Clock className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">{statusCounts['Waitlisted'] || 0}</div>
              <p className="text-xs text-muted-foreground">Pending final allocation</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Match Score</CardTitle>
              <TrendingUp className="h-4 w-4 text-primary-glow" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-glow">
                {Math.round(allocations.reduce((sum, a) => sum + a.matchScore, 0) / allocations.length)}%
              </div>
              <p className="text-xs text-muted-foreground">AI matching accuracy</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Actions */}
        <Card className="mb-6 bg-gradient-card border-0 shadow-card">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex-1 max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search by applicant name, internship, or company..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
                <Button variant="professional" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export Results
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Allocations List */}
        <div className="space-y-4">
          {filteredAllocations.map((allocation) => (
            <Card key={allocation.id} className="bg-gradient-card border-0 shadow-card hover:shadow-elegant transition-smooth">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(allocation.status)}
                      <Badge className={getStatusColor(allocation.status)}>
                        {allocation.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Match Score: <span className="font-semibold text-primary">{allocation.matchScore}%</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Preference: <span className="font-semibold text-accent">#{allocation.preferenceRank}</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Applicant Details */}
                  <div className="space-y-3">
                    <h3 className="font-semibold text-foreground flex items-center gap-2">
                      <User className="h-4 w-4 text-primary" />
                      Applicant Details
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="font-medium text-foreground">{allocation.applicant?.name}</span>
                        <div className="text-muted-foreground">{allocation.applicant?.email}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span>Education: <span className="font-medium">{allocation.applicant?.education}</span></span>
                        <span>CGPA: <span className="font-medium text-primary">{allocation.applicant?.cgpa}</span></span>
                      </div>
                      <div>
                        <span>Location: <span className="font-medium">{allocation.applicant?.location}</span></span>
                        <span className="ml-4">Category: <span className="font-medium">{allocation.applicant?.category}</span></span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {allocation.applicant?.skills.slice(0, 4).map(skill => (
                          <Badge key={skill} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {(allocation.applicant?.skills.length || 0) > 4 && (
                          <Badge variant="outline" className="text-xs">
                            +{(allocation.applicant?.skills.length || 0) - 4} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Internship Details */}
                  <div className="space-y-3">
                    <h3 className="font-semibold text-foreground flex items-center gap-2">
                      <Briefcase className="h-4 w-4 text-secondary" />
                      Allocated Internship
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="font-medium text-foreground">{allocation.internship?.title}</span>
                        <div className="text-muted-foreground">{allocation.internship?.company}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span>Domain: <span className="font-medium">{allocation.internship?.domain}</span></span>
                        <span>Duration: <span className="font-medium">{allocation.internship?.duration}</span></span>
                      </div>
                      <div>
                        <span>Location: <span className="font-medium">{allocation.internship?.location}</span></span>
                        <span className="ml-4">Stipend: <span className="font-medium text-secondary">₹{allocation.internship?.stipend.toLocaleString()}</span></span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {allocation.internship?.requiredSkills.slice(0, 4).map(skill => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {(allocation.internship?.requiredSkills.length || 0) > 4 && (
                          <Badge variant="outline" className="text-xs">
                            +{(allocation.internship?.requiredSkills.length || 0) - 4} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Matching Explanation */}
                <div className="mt-4 p-3 bg-muted/30 rounded-lg">
                  <div className="text-sm">
                    <span className="font-medium text-foreground">AI Matching Explanation: </span>
                    <span className="text-muted-foreground">{allocation.explanation}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredAllocations.length === 0 && searchTerm && (
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardContent className="py-12 text-center">
              <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No results found</h3>
              <p className="text-muted-foreground">Try adjusting your search criteria</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Allocations;