import { Button } from "@/components/ui/enhanced-button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/layout/Header";
import { Link } from "react-router-dom";
import { 
  Brain, 
  Target, 
  Users, 
  TrendingUp, 
  Award, 
  CheckCircle, 
  ArrowRight,
  Sparkles,
  Shield,
  Zap,
  Building2,
  GraduationCap,
  MapPin
} from "lucide-react";

const NewIndex = () => {
  const features = [
    {
      icon: Brain,
      title: "AI-Powered Matching",
      description: "Advanced algorithms analyze skills, preferences, and qualifications for optimal placement",
      color: "text-primary"
    },
    {
      icon: Target,
      title: "Smart Allocation",
      description: "Maximize satisfaction while ensuring fairness and diversity across all categories",
      color: "text-secondary"
    },
    {
      icon: Shield,
      title: "Fairness Guaranteed",
      description: "Built-in bias detection and reservation quota compliance for equitable outcomes",
      color: "text-accent"
    },
    {
      icon: Zap,
      title: "Real-time Processing",
      description: "Process thousands of applications instantly with transparent explanations",
      color: "text-primary-glow"
    }
  ];

  const stats = [
    { label: "Success Rate", value: "94%", icon: Award },
    { label: "Avg Match Score", value: "87%", icon: Target },
    { label: "Processing Time", value: "<5min", icon: Zap },
    { label: "Satisfaction", value: "4.8/5", icon: Users }
  ];

  const benefits = [
    "Eliminates manual bias and human error",
    "Ensures compliance with reservation policies",
    "Maximizes applicant preference satisfaction",
    "Reduces administrative workload by 90%",
    "Provides explainable allocation decisions",
    "Supports diversity and inclusion goals"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-5" />
        <div className="container mx-auto text-center relative">
          <div className="max-w-4xl mx-auto">
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
              <Sparkles className="h-3 w-3 mr-1" />
              AI-Powered Smart Allocation
            </Badge>
            <h1 className="text-5xl lg:text-6xl font-bold mb-6">
              <span className="bg-gradient-hero bg-clip-text text-transparent">
                Smart Allocation Engine
              </span>
              <br />
              <span className="text-foreground">for PM Internship Scheme</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              Revolutionary AI system that matches interns to opportunities with unprecedented accuracy, 
              ensuring fairness, transparency, and optimal outcomes for all stakeholders.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild variant="hero" size="xl">
                <Link to="/apply">
                  <Users className="h-5 w-5 mr-2" />
                  Apply for Internship
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Link>
              </Button>
              <Button asChild variant="professional" size="xl">
                <Link to="/dashboard">
                  <Brain className="h-5 w-5 mr-2" />
                  Admin Dashboard
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center bg-gradient-card border-0 shadow-card hover:shadow-elegant transition-smooth">
                <CardContent className="pt-6">
                  <stat.icon className="h-8 w-8 mx-auto mb-4 text-primary" />
                  <div className="text-3xl font-bold text-foreground mb-2">{stat.value}</div>
                  <p className="text-muted-foreground">{stat.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              How Our AI Engine Works
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Cutting-edge technology meets human-centered design for perfect internship matches
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="bg-gradient-card border-0 shadow-card hover:shadow-elegant transition-smooth group">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-muted/50 flex items-center justify-center group-hover:scale-110 transition-bounce`}>
                    <feature.icon className={`h-8 w-8 ${feature.color}`} />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-foreground mb-6">
                Why Choose Our Smart Allocation System?
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Traditional manual allocation processes are prone to bias, inefficiency, and human error. 
                Our AI-powered system revolutionizes internship allocation with fairness and precision.
              </p>
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="h-6 w-6 text-secondary flex-shrink-0 mt-0.5" />
                    <span className="text-foreground font-medium">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <Card className="bg-gradient-primary text-white border-0 shadow-glow">
                <CardContent className="pt-6 text-center">
                  <Building2 className="h-12 w-12 mx-auto mb-4" />
                  <div className="text-2xl font-bold mb-2">500+</div>
                  <p className="opacity-90">Partner Organizations</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-success text-white border-0 shadow-elegant">
                <CardContent className="pt-6 text-center">
                  <GraduationCap className="h-12 w-12 mx-auto mb-4" />
                  <div className="text-2xl font-bold mb-2">10K+</div>
                  <p className="opacity-90">Students Placed</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-card border-0 shadow-card">
                <CardContent className="pt-6 text-center">
                  <MapPin className="h-12 w-12 mx-auto mb-4 text-accent" />
                  <div className="text-2xl font-bold text-foreground mb-2">28</div>
                  <p className="text-muted-foreground">States Covered</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-card border-0 shadow-card">
                <CardContent className="pt-6 text-center">
                  <Award className="h-12 w-12 mx-auto mb-4 text-primary" />
                  <div className="text-2xl font-bold text-foreground mb-2">95%</div>
                  <p className="text-muted-foreground">Completion Rate</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <Card className="bg-gradient-hero text-white border-0 shadow-glow max-w-4xl mx-auto">
            <CardContent className="py-16">
              <h2 className="text-4xl font-bold mb-6">
                Ready to Transform Internship Allocation?
              </h2>
              <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
                Join the future of fair, efficient, and AI-powered internship matching. 
                Whether you're an applicant or administrator, we've got you covered.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="secondary" size="xl">
                  <Link to="/apply">
                    Start Your Application
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="xl" className="border-white text-white hover:bg-white hover:text-primary">
                  <Link to="/analytics">
                    View Success Stories
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border bg-muted/30">
        <div className="container mx-auto text-center">
          <p className="text-muted-foreground">
            © 2024 Smart Allocation Engine - PM Internship Scheme. Powered by AI for Fair Opportunities.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default NewIndex;