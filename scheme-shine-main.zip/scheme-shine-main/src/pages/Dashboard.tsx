import { Button } from "@/components/ui/enhanced-button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { dummyApplicants, dummyInternships, generateDummyAllocations } from "@/data/dummyData";
import { Users, Building2, Target, TrendingUp, MapPin, GraduationCap, Briefcase, Award } from "lucide-react";
import { useMemo } from "react";

const Dashboard = () => {
  const allocations = useMemo(() => generateDummyAllocations(), []);
  
  const stats = useMemo(() => {
    const totalApplicants = dummyApplicants.length;
    const totalInternships = dummyInternships.length;
    const totalPositions = dummyInternships.reduce((sum, int) => sum + int.capacity, 0);
    const allocated = allocations.filter(a => a.status === 'Allocated').length;
    const avgMatchScore = Math.round(
      allocations.reduce((sum, a) => sum + a.matchScore, 0) / allocations.length
    );
    
    return {
      totalApplicants,
      totalInternships,
      totalPositions,
      allocated,
      allocationRate: Math.round((allocated / totalApplicants) * 100),
      avgMatchScore,
    };
  }, [allocations]);

  const topSkills = useMemo(() => {
    const skillCount: Record<string, number> = {};
    dummyApplicants.forEach(applicant => {
      applicant.skills.forEach(skill => {
        skillCount[skill] = (skillCount[skill] || 0) + 1;
      });
    });
    return Object.entries(skillCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 6);
  }, []);

  const categoryDistribution = useMemo(() => {
    const categories: Record<string, number> = {};
    dummyApplicants.forEach(applicant => {
      categories[applicant.category] = (categories[applicant.category] || 0) + 1;
    });
    return categories;
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Monitor and manage the PM Internship allocation process</p>
        </div>

        {/* Key Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-card border-0 shadow-card hover:shadow-elegant transition-smooth">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Applicants</CardTitle>
              <Users className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{stats.totalApplicants}</div>
              <p className="text-xs text-muted-foreground">Active applications</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card hover:shadow-elegant transition-smooth">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Internship Programs</CardTitle>
              <Building2 className="h-4 w-4 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary">{stats.totalInternships}</div>
              <p className="text-xs text-muted-foreground">{stats.totalPositions} total positions</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card hover:shadow-elegant transition-smooth">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Allocation Rate</CardTitle>
              <Target className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">{stats.allocationRate}%</div>
              <p className="text-xs text-muted-foreground">{stats.allocated} allocated</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-0 shadow-card hover:shadow-elegant transition-smooth">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Match Quality</CardTitle>
              <TrendingUp className="h-4 w-4 text-primary-glow" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-glow">{stats.avgMatchScore}%</div>
              <p className="text-xs text-muted-foreground">Average match score</p>
            </CardContent>
          </Card>
        </div>

        {/* Allocation Progress */}
        <Card className="mb-8 bg-gradient-card border-0 shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              Allocation Progress
            </CardTitle>
            <CardDescription>Real-time status of internship allocations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between text-sm font-medium">
                <span>Allocated</span>
                <span>{stats.allocated}/{stats.totalApplicants}</span>
              </div>
              <Progress value={stats.allocationRate} className="h-2" />
              <div className="flex justify-between gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-secondary rounded-full"></div>
                  <span>Allocated: {allocations.filter(a => a.status === 'Allocated').length}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-accent rounded-full"></div>
                  <span>Waitlisted: {allocations.filter(a => a.status === 'Waitlisted').length}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-muted rounded-full"></div>
                  <span>Pending: {allocations.filter(a => a.status === 'Not Allocated').length}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Top Skills */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-primary" />
                Most In-Demand Skills
              </CardTitle>
              <CardDescription>Skills frequently mentioned by applicants</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {topSkills.map(([skill, count]) => (
                  <div key={skill} className="flex items-center justify-between">
                    <Badge variant="secondary" className="font-medium">{skill}</Badge>
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-muted rounded h-2">
                        <div 
                          className="bg-primary h-2 rounded" 
                          style={{ width: `${(count / dummyApplicants.length) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-8">{count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Category Distribution */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-secondary" />
                Category Distribution
              </CardTitle>
              <CardDescription>Applicant distribution by reservation category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(categoryDistribution).map(([category, count]) => (
                  <div key={category} className="flex items-center justify-between">
                    <span className="font-medium">{category}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-muted rounded h-2">
                        <div 
                          className="bg-secondary h-2 rounded" 
                          style={{ width: `${(count / dummyApplicants.length) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-8">{count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="bg-gradient-card border-0 shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-accent" />
              Quick Actions
            </CardTitle>
            <CardDescription>Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="professional" className="justify-start h-auto p-4">
                <div className="text-left">
                  <div className="font-medium">Run Allocation</div>
                  <div className="text-sm opacity-90">Execute smart matching algorithm</div>
                </div>
              </Button>
              <Button variant="success" className="justify-start h-auto p-4">
                <div className="text-left">
                  <div className="font-medium">Export Results</div>
                  <div className="text-sm opacity-90">Download allocation reports</div>
                </div>
              </Button>
              <Button variant="hero" className="justify-start h-auto p-4">
                <div className="text-left">
                  <div className="font-medium">View Analytics</div>
                  <div className="text-sm opacity-90">Detailed performance insights</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;